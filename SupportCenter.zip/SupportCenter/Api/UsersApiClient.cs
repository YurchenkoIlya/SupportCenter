﻿using SupportCenter.Classes;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;

public class UsersApiClient
{
    private readonly HttpClient _client;

    public UsersApiClient()
    {
        _client = new HttpClient
        {
            BaseAddress = new Uri("http://localhost:5179") //  Web API
        };
    }

    public async Task<List<Users>> GetUsersAsync()
    {
        return await _client.GetFromJsonAsync<List<Users>>("api/users/get");
    }

}
