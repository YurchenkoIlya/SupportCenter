﻿using Npgsql;
using SupportCenter.Classes;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Http;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SupportCenter
{
    /// <summary>
    /// Логика взаимодействия для AppealForm.xaml
    /// </summary>
    public partial class AppealForm : Window
    {
        public AppealForm()
        {
            InitializeComponent();
        }

        private void cancelButton_Click(object sender, RoutedEventArgs e)
        {
            var mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }


        private void buttonFolder_Click(object sender, RoutedEventArgs e)
        {
            workAreaControl.SelectedIndex = 1;
            loadFolder();

        }
        public void loadFolder()
        {
            dbConnect db_connect = new dbConnect();
            NpgsqlCommand command = new NpgsqlCommand(
                        "SELECT u.id_appeal, " +            
                        "applicant.user_name AS applicant_username, " +
                        "p.name_folder, " +
                        "responsible.user_name AS responsible_username, " +
                        "u.status_responsible, " +
                        "otp_user.user_name AS otp_username, " +
                        "u.status_executor, " +
                        "u.comment " +
                        "FROM main.appealfolder u " +
                        "LEFT JOIN main.users applicant ON u.applicant = applicant.user_id " +
                        "LEFT JOIN main.users responsible ON u.responsible = responsible.user_id " +
                        "LEFT JOIN main.users otp_user ON u.executor = otp_user.user_id " +                     
                        "LEFT JOIN main.folders p ON u.folder = p.id", db_connect.GetConnection());
            db_connect.openConnection();
            command.ExecuteNonQuery();
            NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(command);
            NpgsqlDataReader reader = command.ExecuteReader();
            List<appealFolder> result = new List<appealFolder>();

            while (reader.Read())
            {
                string? responsibleStatus = null;
                string? executeStatus = null;
                string? otpExecutor = null;




                  switch (Convert.ToString(reader[4]))
                  {
                    case "0": responsibleStatus = "Не согласовано"; break;
                    case "1": responsibleStatus = "Согласовано"; break;
                    case "2": responsibleStatus = "Отказано"; break;

                  }
                  switch (Convert.ToString(reader[6]))
                  {
                      case "0": executeStatus = "Не в работе"; break;
                      case "1": executeStatus = "В работе"; break;
                      case "2": executeStatus = "Выполнено"; break;
                      case "3": executeStatus = "Отменено"; break;

                  }
                  if (Convert.ToString(reader[5]) == "")
                  {
                      otpExecutor = "Нет исполнителя";
                  }
                  else otpExecutor = Convert.ToString(reader[9]);



                result.Add(new appealFolder(Convert.ToInt32(reader[0]), Convert.ToString(reader[1]), Convert.ToString(reader[2]), Convert.ToString(reader[3]),
                    responsibleStatus, otpExecutor, executeStatus, Convert.ToString(reader[7])));

            }
            reader.Close();


            if (Session.Role == 1 || Session.CurrentUserName == "Ерахтин Артем Максимович" || Session.CurrentUserName == "Пасынков Сергей Андреевич")
                myAppealsFolder.IsEnabled = true;

            var queryResult = result.AsQueryable();

            if (myAppealsFolder.IsChecked == true)
                queryResult = queryResult.Where(u => u.idApplicant == Session.CurrentUserName);
            if (!string.IsNullOrWhiteSpace(applicantFolderTextBlock?.Text))
                queryResult = queryResult.Where(u =>
             (u.idApplicant != null && u.idApplicant.IndexOf(applicantFolderTextBlock.Text, StringComparison.OrdinalIgnoreCase) >= 0));
            if (responsibleStatusFolder?.IsChecked == true)
                queryResult = queryResult.Where(u => u.statusResponsible == "Согласовано");



            appealFolderDataGrid.ItemsSource = queryResult;





        }

        public async void loadAppealProgram()
        {

            var api = new AppealProgramApi();
            var appeals = await api.GetAppealProgramsAsync();

            var queryResult = appeals.AsQueryable();

            if(Session.Role == 1 /*|| Session.CurrentUserName == "Ерахтин Артем Максимович" || Session.CurrentUserName == "Пасынков Сергей Андреевич"*/)
                activityCheckBox.IsEnabled = true;


            if (activityCheckBox.IsChecked == true)
                queryResult = queryResult.Where(u => u.applicant_user == Session.CurrentUserName);
            if (applicantTextBox.Text != "")
                queryResult = queryResult.Where(u =>
             (u.applicant_user != null && u.applicant_user.IndexOf(applicantTextBox.Text, StringComparison.OrdinalIgnoreCase) >= 0));
            if (searchIdAppeal.Text != "")
                queryResult = queryResult.Where(u => u.id_appeal_program == Convert.ToInt32(searchIdAppeal.Text));
            if (executeTextBox.Text != "")
                queryResult = queryResult.Where(u =>
             (u.otp_executor!= null && u.otp_executor.IndexOf(executeTextBox.Text, StringComparison.OrdinalIgnoreCase) >= 0));
            if (statusOitCheckBox.IsChecked == true)
                queryResult = queryResult.Where(u => u.oit_status == "Согласовано");
            if (statusOibCheckBox.IsChecked == true)
                queryResult = queryResult.Where(u => u.oib_status == "Согласовано");





            appealProgramDataGrid.ItemsSource = queryResult;



        }

        private void appealProgramCreate_Click(object sender, RoutedEventArgs e)
        {
            CreateAppealProgramForm createAppealProgramForm = new CreateAppealProgramForm();
            createAppealProgramForm.ShowDialog();
        }

        private void appealProgramShow_Click(object sender, RoutedEventArgs e)
        {
            workAreaControl.SelectedIndex = 0;
            loadAppealProgram();
        }

        private void appealProgramDataGrid_AutoGeneratedColumns(object sender, EventArgs e)
        {
            appealProgramDataGrid.Columns[0].Header = "ID";
            appealProgramDataGrid.Columns[1].Header = "ПРОГРАММА";
            appealProgramDataGrid.Columns[2].Header = "КОМПЬЮТЕР";
            appealProgramDataGrid.Columns[3].Header = "IP АДРЕС";
            appealProgramDataGrid.Columns[4].Header = "ИЦИЦИАТОР";
            appealProgramDataGrid.Columns[5].Header = "СОГЛАСУБЮЩИЙ ОИБ";
            appealProgramDataGrid.Columns[6].Header = "СТАТУС";
            appealProgramDataGrid.Columns[7].Header = "СОГЛАСУЮЩИЙ ОИТ";
            appealProgramDataGrid.Columns[8].Header = "СТАТУС";
            appealProgramDataGrid.Columns[9].Header = "ИСПОЛНИТЕЛЬ ОТП";
            appealProgramDataGrid.Columns[10].Header = "ЭТАП ВЫПОЛНЕНИЯ";
            appealProgramDataGrid.Columns[0].Width = 35;
        }

        private void appealProgramView_Click(object sender, RoutedEventArgs e)
        {




            AppealProgramDto? path = appealProgramDataGrid.SelectedItem as AppealProgramDto;
            if (path != null)
            {
                ViewAppealProgramForm viewAppealProgramForm = new ViewAppealProgramForm();

                viewAppealProgramForm.idAppeal.Text = Convert.ToString(path.id_appeal_program);

                viewAppealProgramForm.ShowDialog();
                loadAppealProgram();
            }
            else
            {
                MessageBox.Show("Выберите обращение из списка");
            }


                


        }

        private void buttonPrinter_Click(object sender, RoutedEventArgs e)
        {
            workAreaControl.SelectedIndex = 2;
            loadPrinter();
        }
        public void loadPrinter()
        {

            dbConnect db_connect = new dbConnect();
            NpgsqlCommand command = new NpgsqlCommand(
                        @"SELECT u.id_appeal, u.ip_pc, u.name_pc, u.model_printer, u.ip_printer,
                        executor.user_name AS executor_username,
                        u.status_execute,
                        u.comment,
                        applicant.user_name AS applicant_username
                        FROM main.appealprinter u
                        LEFT JOIN main.users executor ON u.executor = executor.user_id
                        LEFT JOIN main.users applicant ON u.applicant = applicant.user_id" , db_connect.GetConnection());

            db_connect.openConnection();
            NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(command);
            NpgsqlDataReader reader = command.ExecuteReader();
            List<AppealPrinter> result = new List<AppealPrinter>();

            while (reader.Read())
            {
                string? executeStatus = null;
                




                switch (Convert.ToString(reader[6]))
                {
                    case "0": executeStatus = "Не в работе"; break;
                    case "1": executeStatus = "В работе"; break;
                    case "2": executeStatus = "Выполнено"; break;
                    case "3": executeStatus = "Отменено"; break;

                }
                string executorName = reader.IsDBNull(5) ? "Не назначен" : reader.GetString(5);



                result.Add(new AppealPrinter
                {
                    id_appeal = reader.GetInt32(0),
                    ip_pc = reader.GetString(1),
                    name_pc = reader.GetString(2),
                    model_printer = reader.GetString(3),
                    ip_printer = reader.GetString(4),
                    executor = executorName,
                    status_execute = executeStatus,
                    comment = reader.GetString(7),
                    applicant = reader.GetString(8) 
                });

            }
            reader.Close();
            printerDataGrid.ItemsSource = result;
           







        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            loadAppealProgram();

            programTabItem.Visibility = Visibility.Collapsed;
            foldersTabItem.Visibility = Visibility.Collapsed;
            PrintersTabItem.Visibility = Visibility.Collapsed;
            
        }

        private void appealFolderView_Click(object sender, RoutedEventArgs e)
        {

            appealFolder? path = appealFolderDataGrid.SelectedItem as appealFolder;
            if (path != null)
            {
                ViewAppealFolderForm viewAppealFolder = new ViewAppealFolderForm();
               

                viewAppealFolder.idAppeal.Text = Convert.ToString(path.idAppeal);

                viewAppealFolder.ShowDialog();
                loadAppealProgram();
            }
            else
            {
                MessageBox.Show("Выберите обращение из списка");
            }

            

        }

        private void appealFolderDataGrid_AutoGeneratedColumns(object sender, EventArgs e)
        {
            appealFolderDataGrid.Columns[0].Header = "ID";
            appealFolderDataGrid.Columns[1].Header = "ИНИЦИАТОР";
            appealFolderDataGrid.Columns[2].Header = "ПАПКА";
            appealFolderDataGrid.Columns[3].Header = "ОТВЕТСТВЕННЫЙ";
            appealFolderDataGrid.Columns[4].Header = "СТАТУС СОГЛАСОВАНИЯ";
            appealFolderDataGrid.Columns[5].Header = "ИСПОЛНИТЕЛЬ";
            appealFolderDataGrid.Columns[6].Header = "СТАТУС ВЫПОЛНЕНИЯ";
            appealFolderDataGrid.Columns[7].Header = "КОММЕНТАРИЙ";
            appealFolderDataGrid.Columns[0].Width = 35;
        }

        private void appealFolderCreate_Click(object sender, RoutedEventArgs e)
        {
            CreateAppealFolderForm createAppealFolderForm = new CreateAppealFolderForm();
            createAppealFolderForm.ShowDialog();
        }

        private void printerAppealView_Click(object sender, RoutedEventArgs e)
        {
            AppealPrinter? path = printerDataGrid.SelectedItem as AppealPrinter;

            if (path != null)
            {
                ViewAppealPrintForm viewAppealPrintForm = new ViewAppealPrintForm(path.id_appeal);
                viewAppealPrintForm.ShowDialog();
                loadPrinter();
            }
            else
            {
                MessageBox.Show("Не выбрана папка из списка");
            }

        }

        private void appealPrinterCreate_Click(object sender, RoutedEventArgs e)
        {
            CreateAppealPrintForm createAppealPrint = new CreateAppealPrintForm();
            createAppealPrint.ShowDialog(); 
        }

       

        

        private void applicantTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            loadAppealProgram();
        }

        private void activityCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            loadAppealProgram();
        }

        private void activityCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            loadAppealProgram();
        }

        private void searchIdAppeal_TextChanged(object sender, TextChangedEventArgs e)
        {
            loadAppealProgram();
        }

        private void executeTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            loadAppealProgram();
        }

        private void statusOitCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            loadAppealProgram();
        }

        private void statusOitCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            loadAppealProgram();
        }

        private void statusOibCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            loadAppealProgram();
        }

        private void statusOibCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            loadAppealProgram();
        }

        private void applicantFolderTextBlock_TextChanged(object sender, TextChangedEventArgs e)
        {
            loadFolder();
        }

        private void myAppealsFolder_Checked(object sender, RoutedEventArgs e)
        {
            loadFolder();
        }

        private void myAppealsFolder_Unchecked(object sender, RoutedEventArgs e)
        {
            loadFolder();
        }

        private void responsibleStatusFolder_Checked(object sender, RoutedEventArgs e)
        {
            loadFolder();
        }

        private void responsibleStatusFolder_Unchecked(object sender, RoutedEventArgs e)
        {
            loadFolder();
        }
    }
}
