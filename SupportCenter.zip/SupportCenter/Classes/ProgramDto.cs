﻿namespace SupportCenter.Classes
{
    public class ProgramDto
    {
        public int id_program { get; set; }
        public string name_program { get; set; }
        public string way_program { get; set; }
    }
}
