﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SupportCenter.Classes
{
    public class folderResponsible
    {
  
        public int Id { get; set; }
        public string nameFolder { get; set; }
        public string responsibleUser { get; set; }
        public string wayFolder { get; set; }
        public string accessGroup { get; set; }
    }
}
