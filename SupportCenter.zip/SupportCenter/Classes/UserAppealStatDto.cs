﻿namespace WebApplication1.Dto
{
    public class UserAppealStatDto
    {
        public string UserName { get; set; }
        public int DoneCount { get; set; }
        public int InWorkCount { get; set; }
    }

}
