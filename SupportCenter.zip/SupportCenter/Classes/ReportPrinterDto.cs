﻿namespace WebApplication1.Dto
{
    public class ReportPrinterDto
    {
  
            public int Total { get; set; }
            public int InWork { get; set; }
            public int Done { get; set; }
            public int NotDone { get; set; }
        
    }
}
